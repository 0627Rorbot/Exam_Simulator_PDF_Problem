import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import axios from "axios";
// import { Viewer } from '@react-pdf-viewer/core';
// import '@react-pdf-viewer/core/lib/styles/index.css';
import ReactPDF from 'intelllex/react-pdf';
// import { Document } from 'react-pdf/dist/esm/entry.webpack';
import {
  Box,
  FormControl,
  FormLabel,
  Button,
  SimpleGrid,
  Stack,
  Input,
} from "@chakra-ui/react";

window.Buffer = window.Buffer || require("buffer").Buffer;

const awsConfig = {
  bucketName: process.env.REACT_APP_AWS_BUCKET_NAME,
  region: process.env.REACT_APP_AWS_REGION,
  accessKeyId: process.env.REACT_APP_AWS_ACCESS_ID,
  secretAccessKey: process.env.REACT_APP_AWS_ACCESS_KEY,
};

const Problem = () => {
  const [fileUrl, setFileUrl] = useState(undefined);
  const [pdf_file, setPdf_File] = useState(undefined);

  const onFileChange = (event) => {
    const file = event.target.files[0];
    setPdf_File(file);
    if (file) {
      const url = URL.createObjectURL(file);
      setFileUrl(url);
    }
  };

  const onAdd = () => {
    console.log("PDF file upload");
    let file = pdf_file;
    const formData = new FormData();

    formData.append("file", file);

    axios
      .post(process.env.REACT_APP_API_BASE + "api/problem", formData)
      .then((res) => console.log(res))
      .catch((err) => console.warn(err));
  };

  return (
    <>
      <Header></Header>
      {/* <form onSubmit={uploadFiles} style={{ paddingTop: "30px" }}> */}
      <SimpleGrid columns={2} spacing={10} px={10}>
        <Box pt={5}>
          <FormControl isRequired>
            <FormLabel>Problem Title</FormLabel>
            <Input placeholder="exam 1" />
          </FormControl>

          <FormControl isRequired>
            <FormLabel>PDF Exam</FormLabel>
            <Input
              type="file"
              accept=".pdf"
              onChange={(e) => onFileChange(e)}
            />
          </FormControl>
          <Button colorScheme="blue" onClick={() => onAdd()}>
            Insert Problem
          </Button>
        </Box>
        <Box>
          <Stack spacing={4}>
            <FormControl>
              <FormLabel>PDF View</FormLabel>
              {fileUrl ? (
                <hive-pdf-viewer src={fileUrl}></hive-pdf-viewer>
              ) : (
                <div
                  style={{
                    alignItems: "center",
                    border: "2px dashed rgba(0, 0, 0, .3)",
                    display: "flex",
                    fontSize: "2rem",
                    height: "100%",
                    justifyContent: "center",
                    width: "100%",
                  }}
                >
                  Preview area
                </div>
              )}
            </FormControl>
          </Stack>
        </Box>
      </SimpleGrid>
    </>
  );
};

export default Problem;
