const Result = () => {
  return (
    <div>
      <h1>Result</h1>
      <h1>Result</h1>
      <h1>Result</h1>
      <h1>Result</h1>
      <h1>Result</h1>
      <h1>Result</h1>
    </div>
  )
}

export default Result;